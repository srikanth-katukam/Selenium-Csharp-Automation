﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject.BaseClass;
using TestProject.Utilities;

namespace TestProject.Pages
{
    class HomePage : BaseTest
    {
        private static readonly string SIGNIN = "//a[@class='login']";
        private static readonly string EMAILID = "email_create";
        private static readonly string CREATEBUTTOn = "SubmitCreate";


        public void ClickOnSignIn()
        {
            Waits.WaitForAnElement(By.XPath(SIGNIN), 5);
            driver.FindElement(By.XPath(SIGNIN)).Click();
        
        }

        public void EnterEmailAddress(string emailId)
        {
            Waits.WaitForAnElement(By.Id(EMAILID), 5);
            driver.FindElement(By.Id(EMAILID)).SendKeys(emailId);

        }
        public void CreateAnAccount()
        {
            Waits.WaitForAnElement(By.Id(CREATEBUTTOn), 5);
            driver.FindElement(By.Id(CREATEBUTTOn)).Click();

        }
    }
}
