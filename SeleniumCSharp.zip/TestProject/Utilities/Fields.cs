﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject.BaseClass;

namespace TestProject.Utilities
{
    public class Fields : BaseTest
    {
        public static void setSelectFieldByValue(string idLocator, string selectValue)
        {

            IWebElement element = driver.FindElement(By.Id(idLocator));
            SelectElement selectOption = new SelectElement(element);
            selectOption.SelectByValue(selectValue);
        }

        public void setSelectFieldByVisibleText(string idLocator, string selectText)
        {

            IWebElement element = driver.FindElement(By.Id(idLocator));
            SelectElement selectOption = new SelectElement(element);
            selectOption.SelectByText(selectText);
        }
    }
}
