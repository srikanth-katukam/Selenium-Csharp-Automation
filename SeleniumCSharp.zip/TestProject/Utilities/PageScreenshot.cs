﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TestProject.Utilities
{
    class PageScreenshot
    {
        public static void TakeScreenshot(IWebDriver driver)
        {

            ScreenshotImageFormat fileFormat = ScreenshotImageFormat.Png;  // Image Format -> Png, Jpeg, Gif, Bmp and Tiff.
                                                                           // string strFileName = String.Format("{0}.{1}", string.Concat(ScenarioContext.ScenarioInfo.Title.Split(Path.GetInvalidFileNameChars())), fileFormat);

            string dateFormat = string.Concat(DateTime.Now.ToString().Split(Path.GetInvalidFileNameChars())).Replace(" ", "");
            string path = Path.GetDirectoryName(Assembly.GetCallingAssembly().Location);
            Screenshot screenshot = ((ITakesScreenshot)driver).GetScreenshot();
            screenshot.SaveAsFile(Path.Combine(path, "Screenshot" + dateFormat) + "." +fileFormat);
        }
    }
}
