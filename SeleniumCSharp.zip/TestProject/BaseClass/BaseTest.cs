﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject.Factory;

namespace TestProject.BaseClass
{
    public class BaseTest
    {
        public static IWebDriver driver;
        public BrowserFactory browserFactory;

        public void Initialization()
        {
            string browser = ConfigurationManager.AppSettings["Browser"];
            string url = ConfigurationManager.AppSettings["Url"];
            driver = BrowserFactory.GetBrowser(browser);
            driver.Url = url;
        }

        public void TearDown()
        {
            driver.Close();
        }

    }
}




