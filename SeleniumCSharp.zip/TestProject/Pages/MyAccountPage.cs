﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject.BaseClass;
using TestProject.Utilities;

namespace TestProject.Pages
{
    class MyAccountPage : BaseTest
    {
        private static readonly string MYACCOUNT = "//a[@title='View my customer account']/span";



        public void VerifyUser(string userFullName)
        {
            Waits.WaitForAnElement(By.XPath(MYACCOUNT), 5);
            string userName =  driver.FindElement(By.XPath(MYACCOUNT)).Text;
            Assert.AreEqual(userFullName, userName);
        
        }

    }
}
