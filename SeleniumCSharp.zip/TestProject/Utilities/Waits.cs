﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject.BaseClass;

namespace TestProject.Utilities
{
    public class Waits : BaseTest
    {
        public static void WaitForAnElement(By by,double time)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(time));
             wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(by));
        }
  
    }
}
