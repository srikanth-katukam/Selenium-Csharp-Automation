﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Linq;
using System.Text.RegularExpressions;
using TestProject.BaseClass;
using TestProject.Pages;
using TestProject.Utilities;

namespace TestProject.Testcases
{
    public class RegistrationTest : BaseTest
    {
        HomePage homePage;
        AccountRegistrationPage registrationPage;
        MyAccountPage accountPage;

        [SetUp]
        public void init()
        {
            Initialization();
        }

        [Test]
        public void Test()
        {
            homePage = new HomePage();
            registrationPage = new AccountRegistrationPage();
            accountPage = new MyAccountPage();

            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string str =  new string(Enumerable.Repeat(chars, 5)
              .Select(s => s[random.Next(s.Length)]).ToArray());

            string emailId = "test" + Regex.Replace(DateTime.Now.ToString(), @"[^0-9a-zA-Z]+", "") + "@gmail.com";
            string password = "pwd" + Regex.Replace(DateTime.Now.ToString(), @"[^0-9a-zA-Z]+", "");
            string firstName = "FirstName" + str;
            string lastName = "LastName" + str;
            
            try
            {
                Console.WriteLine("Registrations Test Block");

                homePage.ClickOnSignIn();
                homePage.EnterEmailAddress(emailId);
                homePage.CreateAnAccount();
                Console.WriteLine("Clicked on Create An Account button");

                registrationPage.ClickTitle("Mrs.");
                registrationPage.FirstName(firstName);
                registrationPage.LastName(lastName);
                registrationPage.verifyEmail(emailId);
                registrationPage.Password(password);
                registrationPage.DateOfBirth("10", "10", "1990");
                registrationPage.verifyFirstName(firstName);
                registrationPage.verifyLastName(lastName);
                registrationPage.Address("test address");
                registrationPage.City("test city");
                registrationPage.State("New York");
                registrationPage.PostalCode("10001");
                registrationPage.Country("United States");
                registrationPage.MobilePhone("1234567890");
                registrationPage.ALIASADDRESS("My Address");
                registrationPage.ClickOnRegister();

                accountPage.VerifyUser(firstName + " " + lastName);
            }
            catch (Exception e)
            {
                PageScreenshot.TakeScreenshot(driver);
                Assert.Fail("Exception occured : " + e.Message.ToString());
            }
        }

        [TearDown]
        public void Close()
        {
            Console.WriteLine("Tear Down Method");
            TearDown();
        }
    }
}
