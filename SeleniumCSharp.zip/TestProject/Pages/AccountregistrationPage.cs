﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestProject.BaseClass;
using TestProject.Utilities;

namespace TestProject.Pages
{
    class AccountRegistrationPage : BaseTest
    {
        private static readonly string TITLEMR = "id_gender1";
        private static readonly string TITLEMRS = "id_gender2";
        private static readonly string FIRSTNAME = "customer_firstname";
        private static readonly string LASTNAME = "customer_lastname";
        private static readonly string EMAIL = "email";
        private static readonly string PASSWORD = "passwd";
        private static readonly string FIRSTNAMEID = "firstname";
        private static readonly string LASTNAMEID = "lastname";
        private static readonly string DAYS = "days";
        private static readonly string MONTHS = "months";
        private static readonly string YEARS = "years";
        private static readonly string ADDRESS1 = "address1";
        private static readonly string CITY = "city";
        private static readonly string STATE = "id_state";
        private static readonly string COUNTRY = "id_country";
        private static readonly string POSTALCODE = "postcode";
        private static readonly string MOBILEPHONE = "phone_mobile";
        private static readonly string ADDRESSALIAS = "alias";
        private static readonly string REGISTER = "submitAccount";

        Fields Fields;
        public void ClickTitle(string title)
        {
            Waits.WaitForAnElement(By.Id(TITLEMR), 5);
            if (title.Equals("Mr."))
                driver.FindElement(By.Id(TITLEMR)).Click();
            else
                driver.FindElement(By.Id(TITLEMRS)).Click();
        }

        public void FirstName(string firstName)
        {
            Waits.WaitForAnElement(By.Id(FIRSTNAME), 5);
            driver.FindElement(By.Id(FIRSTNAME)).SendKeys(firstName);
        }

        public void LastName(string lastName)
        {
            Waits.WaitForAnElement(By.Id(LASTNAME), 5);
            driver.FindElement(By.Id(LASTNAME)).SendKeys(lastName);
        }

        public void verifyEmail(string expectedEmail)
        {
            string actualEmail =  driver.FindElement(By.Id(EMAIL)).GetAttribute("value");
            Assert.AreEqual(expectedEmail, actualEmail);
        }

        public void Password(string password)
        {
            Waits.WaitForAnElement(By.Id(PASSWORD), 5);
            driver.FindElement(By.Id(PASSWORD)).SendKeys(password);
        }

        public void verifyFirstName(string firstName)
        {
            string actualFirstName = driver.FindElement(By.Id(FIRSTNAMEID)).GetAttribute("value");
            Assert.AreEqual(firstName, actualFirstName);
        }
        public void verifyLastName(string lastName)
        {
            string actualLastName = driver.FindElement(By.Id(LASTNAMEID)).GetAttribute("value");
            Assert.AreEqual(lastName, actualLastName);
        }

        public void Address(string address)
        {
            Waits.WaitForAnElement(By.Id(ADDRESS1), 5);
            driver.FindElement(By.Id(ADDRESS1)).SendKeys(address);
        }

        public void City(string city)
        {
            Waits.WaitForAnElement(By.Id(CITY), 5);
            driver.FindElement(By.Id(CITY)).SendKeys(city);
        }

        public void PostalCode(string postalCode)
        {
            Waits.WaitForAnElement(By.Id(POSTALCODE), 5);
            driver.FindElement(By.Id(POSTALCODE)).SendKeys(postalCode);
        }

        public void MobilePhone(string mobilePhone)
        {
            Waits.WaitForAnElement(By.Id(MOBILEPHONE), 5);
            driver.FindElement(By.Id(MOBILEPHONE)).SendKeys(mobilePhone);
        }

        public void ALIASADDRESS(string aliasAddress)
        {
            Waits.WaitForAnElement(By.Id(ADDRESSALIAS), 5);
            driver.FindElement(By.Id(ADDRESSALIAS)).SendKeys(aliasAddress);
        }

        public void ClickOnRegister()
        {
            Waits.WaitForAnElement(By.Id(REGISTER), 5);
            driver.FindElement(By.Id(REGISTER)).Click();
        }
        public void DateOfBirth(string day, string month, string year)
        {
            Fields = new Fields();
            Waits.WaitForAnElement(By.Id(ADDRESSALIAS), 5);
            Fields.setSelectFieldByValue(DAYS, day);
            Fields.setSelectFieldByValue(MONTHS, month);
            Fields.setSelectFieldByValue(YEARS, year);

        }

        public void State(string state)
        {
            Fields = new Fields();
            Waits.WaitForAnElement(By.Id(STATE), 5);
            Fields.setSelectFieldByVisibleText(STATE, state);
        }

        public void Country(string county)
        {
            Fields = new Fields();
            Waits.WaitForAnElement(By.Id(COUNTRY), 5);
            Fields.setSelectFieldByVisibleText(COUNTRY, county);
        }
    }

}
